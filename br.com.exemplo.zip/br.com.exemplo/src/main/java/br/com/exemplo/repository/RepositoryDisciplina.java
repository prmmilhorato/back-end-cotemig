package br.com.exemplo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.exemplo.models.Disciplina;

public interface RepositoryDisciplina extends JpaRepository<Disciplina, Integer> {

}
