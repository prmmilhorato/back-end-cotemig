package br.com.exemplo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.exemplo.models.Curso;
import br.com.exemplo.service.ServiceCurso;
import br.com.exemplo.service.ServiceDisciplina;

@Controller
@RequestMapping("/cursos")
public class ControllerCurso {
	
	@Autowired
	private ServiceCurso serviceCurso;
	
	@Autowired
	private ServiceDisciplina serviceDisciplina;
	
	@GetMapping(value = "")
	public String listALL(Model model) {
		model.addAttribute("cursos", serviceCurso.listALL());
		return "cursos/cursos";
	}
	
	@GetMapping("/novocurso")
	public String novoCurso(Model model) {
		model.addAttribute("curso", new Curso());
		return "cursos/novocurso";
	}
	
	@PostMapping("/salvar")
	public String salvar(@ModelAttribute Curso curso) {
		serviceCurso.salvarCurso(curso);
		return "redirect:/cursos";
	}
	
	@GetMapping("/excluir/{codigo}")
	public String excluirCurso(@PathVariable("codigo") int codigo) {
		
		Curso curso = serviceCurso.getCurso(codigo);
		serviceCurso.excluirCurso(curso);
		
		return "redirect:/cursos";
	}
	
	
	@GetMapping("/adddisciplina/{codigo}")
	public String addDisciplina(@PathVariable("codigo") int codigo, Model model) {
		
		Curso curso = serviceCurso.getCurso(codigo);
		model.addAttribute("curso", curso);
		model.addAttribute("disciplinas", serviceDisciplina.listALL());
		
		return "cursos/adddisciplina";
	}
	
	

}
