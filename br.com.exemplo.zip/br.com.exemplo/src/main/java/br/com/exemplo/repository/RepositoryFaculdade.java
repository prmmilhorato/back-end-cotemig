package br.com.exemplo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.exemplo.models.Faculdade;

@Repository
public interface RepositoryFaculdade extends JpaRepository<Faculdade, Integer>{

}
