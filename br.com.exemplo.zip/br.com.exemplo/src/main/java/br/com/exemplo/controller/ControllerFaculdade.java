package br.com.exemplo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.exemplo.models.Faculdade;
import br.com.exemplo.service.ServiceFaculdade;

@Controller
@RequestMapping("/faculdades")
public class ControllerFaculdade {

	@Autowired
	private ServiceFaculdade serviceFaculdade;
	
	@GetMapping(value = "/novafaculdade")
	public String novaFaculdade(Model model) {
		model.addAttribute("faculdade", new Faculdade());
		return "faculdades/novafaculdade";
	}
	
	@PostMapping(value = "/salvar")
	public String salvar(@ModelAttribute Faculdade faculdade) {
		serviceFaculdade.salvarFaculdade(faculdade);
		return "redirect:/faculdades";
	}
	
	@GetMapping(value = "")
	public String listALL(Model model) {
		model.addAttribute("faculdades", serviceFaculdade.listALL());
		return "faculdades/faculdades";
	}
	
	@GetMapping(value = "/excluir/{codigo}")
	public String excluirFaculdade(@PathVariable("codigo") int id) {
		Faculdade faculdade = serviceFaculdade.getFaculdade(id);
		serviceFaculdade.excluirFaculdade(faculdade);
		
		return "redirect:/faculdades";
	}
	
}
