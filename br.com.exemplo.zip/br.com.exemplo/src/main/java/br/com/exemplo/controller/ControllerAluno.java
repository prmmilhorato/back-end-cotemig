package br.com.exemplo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.exemplo.models.Aluno;
import br.com.exemplo.service.ServiceAluno;
import br.com.exemplo.service.ServiceFaculdade;

@Controller
@RequestMapping("/alunos")
public class ControllerAluno {
	
	@Autowired
	private ServiceAluno serviceAluno;
	
	@Autowired
	private ServiceFaculdade ServiceFaculdade;
	
	@GetMapping(value = "")
	public String listALL(Model model) {
		model.addAttribute("alunos", serviceAluno.listALL());
		return "alunos/alunos";
	}
	
	@GetMapping("/novoaluno")
	public String novoAluno(Model model) {
		model.addAttribute("faculdades", ServiceFaculdade.listALL());
		model.addAttribute("aluno", new Aluno());
		return "alunos/novoaluno";
	}
	
	@PostMapping("/salvar")
	public String salvar(@ModelAttribute Aluno aluno) {
		serviceAluno.salvarAluno(aluno);
		return "redirect:/alunos";
	}
	
	@GetMapping("/excluir/{codigo}")
	public String excluirAluno(@PathVariable("codigo") int codigo) {
		
		Optional<Aluno> optionalAluno = serviceAluno.getAluno(codigo);
		if (optionalAluno.isPresent())
			serviceAluno.excluirAluno(optionalAluno.get());
		
		return "redirect:/alunos";
	}
	
	@GetMapping("/editar/{codigo}")
	public String editarAluno(@PathVariable("codigo") int codigo, Model model) {
		
		model.addAttribute("faculdades", ServiceFaculdade.listALL());
		
		Optional<Aluno> optionalAluno = serviceAluno.getAluno(codigo);
		if (optionalAluno.isPresent())
			model.addAttribute("aluno", optionalAluno.get());
		
		return "alunos/novoaluno";
	}

}
