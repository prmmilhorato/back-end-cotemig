package br.com.exemplo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.exemplo.models.Curso;
import br.com.exemplo.repository.RepositoryCurso;

@Service
public class ServiceCurso {

	@Autowired
	private RepositoryCurso repositoryCurso;
	
	public void salvarCurso(Curso curso) {
		repositoryCurso.save(curso);
	}
	
	public List<Curso> listALL(){
		return repositoryCurso.findAll();
	}
	
	public Curso getCurso(int id) {
		return repositoryCurso.findById(id).get();
	}
	
	public void excluirCurso(Curso curso) {
		repositoryCurso.delete(curso);
	}
}
