package br.com.exemplo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.exemplo.models.Disciplina;
import br.com.exemplo.service.ServiceDisciplina;

@Controller
@RequestMapping("/disciplinas")
public class ControllerDisciplina {
	
	@Autowired
	private ServiceDisciplina serviceDisciplina;
	
	@GetMapping(value = "")
	public String listALL(Model model) {
		model.addAttribute("disciplinas", serviceDisciplina.listALL());
		return "disciplinas/disciplinas";
	}
	
	@GetMapping("/novadisciplina")
	public String novaDisciplina(Model model) {
		model.addAttribute("disciplina", new Disciplina());
		return "disciplinas/novadisciplina";
	}
	
	@PostMapping("/salvar")
	public String salvar(@ModelAttribute Disciplina disciplina) {
		serviceDisciplina.salvarDisciplina(disciplina);
		return "redirect:/disciplinas";
	}
	
	@GetMapping("/excluir/{codigo}")
	public String excluirDisciplina(@PathVariable("codigo") int codigo, RedirectAttributes redirectAttributes) {
		
		try {
			Disciplina disciplina = serviceDisciplina.getDisciplina(codigo);
			serviceDisciplina.excluirDisciplina(disciplina);
			
			redirectAttributes.addFlashAttribute("ok", "Registro excluido com sucesso");
			
			
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
		}
		
		
		return "redirect:/disciplinas";
	}
	
	

}
