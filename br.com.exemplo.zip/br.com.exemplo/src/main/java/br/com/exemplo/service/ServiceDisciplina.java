package br.com.exemplo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.exemplo.models.Disciplina;
import br.com.exemplo.repository.RepositoryDisciplina;

@Service
public class ServiceDisciplina {

	@Autowired
	private RepositoryDisciplina repositoryDisciplina;
	
	public void salvarDisciplina(Disciplina disciplina) {
		repositoryDisciplina.save(disciplina);
	}
	
	public List<Disciplina> listALL(){
		return repositoryDisciplina.findAll();
	}
	
	public Disciplina getDisciplina(int id) {
		return repositoryDisciplina.findById(id).get();
	}
	
	public void excluirDisciplina(Disciplina disciplina) {
		repositoryDisciplina.delete(disciplina);
	}
}
