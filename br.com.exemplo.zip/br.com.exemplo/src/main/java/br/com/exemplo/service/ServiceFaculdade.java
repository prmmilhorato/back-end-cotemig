package br.com.exemplo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.exemplo.models.Faculdade;
import br.com.exemplo.repository.RepositoryFaculdade;

@Service
public class ServiceFaculdade {

	@Autowired
	private RepositoryFaculdade repositoryFaculdade;
	
	public void salvarFaculdade(Faculdade faculdade) {
		repositoryFaculdade.save(faculdade);
	}
	
	public List<Faculdade> listALL(){
		return repositoryFaculdade.findAll();
	}
	
	public Faculdade getFaculdade(int id) {
		return repositoryFaculdade.findById(id).get();
	}
	
	public void excluirFaculdade(Faculdade faculdade) {
		repositoryFaculdade.delete(faculdade);
	}
}
