package br.com.exemplo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.exemplo.models.Aluno;

@Repository
public interface RepositoryAluno extends JpaRepository<Aluno, Integer> {

}
